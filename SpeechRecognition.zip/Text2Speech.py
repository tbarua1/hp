from gtts import gTTS
import pyglet

# This module is imported so that we can
# play the converted audio
import os

# The text that you want to convert to audio
mytext = "Welcome to Python tutotial by Tarkeshwar Barua, Hi there, how is you ?, A B C D E F G H I J K L M N O P Q R S T U V W X Y Z, 0 1 2 3 4 5 6 7 8 9, Sunday Monday Tuesday Wednesday Thursday Friday Saturday Violet Indigo Blue Green Yellow Orange Red, Apple Banana Cherry Date Guava"
# Language in which you want to convert
language = 'hi'
#language = 'en'

# Passing the text and language to the engine,
# here we have marked slow=False. Which tells
# the module that the converted audio should
# have a high speed
myobj = gTTS(text=mytext, lang=language, slow=False)

# Saving the converted audio in a mp3 file named
# welcome
myobj.save("welcome.mp3")

# Playing the converted file

song = pyglet.media.load('output.wav')
song.play()
pyglet.app.run()