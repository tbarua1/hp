import numpy as np
from itertools import combinations, groupby
from collections import Counter
''' support{apple,egg} = 3/5 or 60%
confidence{A->B} = support{A,B} / support{A}   
 confidence{apple->egg} = support{apple,egg} / support{apple}
                                    = (3/5) / (4/5)
                                    = 0.75 or 75%
lift{A,B} = lift{B,A} = support{A,B} / (support{A} * support{B})   
lift{apple,egg} = lift{egg,apple} = support{apple,egg} / (support{apple} * support{egg})
                  = (3/5) / (4/5 * 3/5) 
                  = 1.25  '''
# Sample data
orders = np.array([[1, 'apple'], [1, 'egg'], [1, 'milk'], [2, 'egg'], [2, 'milk']], dtype=object)


# Generator that yields item pairs, one at a time
def get_item_pairs(order_item):
    # For each order, generate a list of items in that order
    for order_id, order_object in groupby(orders, lambda x: x[0]):
        item_list = [item[1] for item in order_object]

        # For each item list, generate item pairs, one at a time
        for item_pair in combinations(item_list, 2):
            yield item_pair

        # Counter iterates through the item pairs returned by our generator and keeps a tally of their occurrence


print(Counter(get_item_pairs(orders)))