from copy import deepcopy
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
def dist(a, b, ax=1):
    return np.linalg.norm(a - b, axis=ax)

plt.rcParams['figure.figsize'] = (16, 9)
plt.style.use('ggplot')
data = pd.read_csv('xclara.csv')
print(data.shape)
print(data.head())

f1 = data['V1'].values
f2 = data['V2'].values
X = np.array(list(zip(f1, f2)))
k = 3
# X coordinates of random centroids
C_x = np.random.randint(0, np.max(X)-20, size=k)
# Y coordinates of random centroids
C_y = np.random.randint(0, np.max(X)-20, size=k)
C = np.array(list(zip(C_x, C_y)), dtype=np.float32)
print(C)
plt.scatter(f1, f2, c='#050505', s=7)
plt.scatter(C_x, C_y, marker='*', s=200, c='g')

plt.show()