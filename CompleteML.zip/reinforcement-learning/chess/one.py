#! /usr/bin/env python
"""
 Project: Python Chess
 File name: ChessBoard.py
 Description:  A simple, text-based chess game
 Copyright (C) 2009 Steve Osborne, srosborne (at) gmail.com

 *******
 This program is free software; you can redistribute it and/or modify 
 it under the terms of the GNU General Public License as published by 
 the Free Software Foundation; either version 2 of the License, or 
 (at your option) any later version.

 This program is distributed in the hope that it will be useful, but 
 WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
 or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License 
 for more details.

 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.

 *******
 Version history:

 v 0.1 - 01 April 2009.  Initial release.  Draws the board, accepts
   move commands from each player, checks for legal piece movement.
   Appropriately declares player in check or checkmate.


 To do:
   Exception handling for bad input
   Color light/dark squares
   Highlight currently selected piece
   Highlight valid moves for selected piece
   Be able to undo piece selection when in "to" square selection method
   Add in AI
   Graphical, point and click interface rather than text based

"""


class ChessBoard():

    def IsCheckmate(self):
        # check if 'whoseturn' is in checkmate
        # Call GetListOfValidMoves for each piece of current player
        # If there aren't any valid moves for any pieces, then return true

        if self.whoseturn == "black":
            myColor = 'b'
            enemyColor = 'w'
        else:
            myColor = 'w'
            enemyColor = 'b'

        myColorValidMoves = [];
        for row in range(8):
            for col in range(8):
                piece = self.squares[row][col]
                if myColor in piece:
                    myColorValidMoves.extend(self.GetListOfValidMoves((row, col)))

        if len(myColorValidMoves) == 0:
            return True
        else:
            return False

    def IsInCheck(self):
        # check if 'whoseturn' is in check
        # scan through squares for all enemy pieces; if there IsLegalMove to whoseturn's king, then return True.
        if self.whoseturn == "black":
            myColor = 'b'
            enemyColor = 'w'
        else:
            myColor = 'w'
            enemyColor = 'b'

        kingTuple = (0, 0)
        # First, get current player's king location    
        for row in range(8):
            for col in range(8):
                piece = self.squares[row][col]
                if 'K' in piece and myColor in piece:
                    kingTuple = (row, col)

        # Check if any of enemy player's pieces has a legal move to current player's king
        for row in range(8):
            for col in range(8):
                piece = self.squares[row][col]
                if enemyColor in piece:
                    # need to temporarily switch whoseturn due to the way IsLegalMove works!
                    self.SwitchWhoseTurn()
                    if self.IsLegalMove((row, col), kingTuple):
                        self.SwitchWhoseTurn()
                        return True
                    self.SwitchWhoseTurn()

        return False

    def SwitchWhoseTurn(self):
        if self.whoseturn == "black":
            self.whoseturn = "white"
        else:
            self.whoseturn = "black"

    def DoesMovePutPlayerInCheck(self, fromTuple, toTuple):
        # makes a hypothetical move; returns True if it puts current player into check
        fromSquare_r = fromTuple[0]
        fromSquare_c = fromTuple[1]
        toSquare_r = toTuple[0]
        toSquare_c = toTuple[1]
        fromPiece = self.squares[fromSquare_r][fromSquare_c]
        toPiece = self.squares[toSquare_r][toSquare_c]

        self.squares[toSquare_r][toSquare_c] = fromPiece
        self.squares[fromSquare_r][fromSquare_c] = 'e'

        retval = self.IsInCheck()

        # undo temporary move
        self.squares[toSquare_r][toSquare_c] = toPiece
        self.squares[fromSquare_r][fromSquare_c] = fromPiece

        # print "###Diag: DoesMovePutPlayerInCheck? ",fromTuple," to ",toTuple,": ",retval

        return retval

    def GetPlayerInput_SquareFrom(self):
        ch = "?"
        cmd_r = 0
        cmd_c = 0
        while (ch not in self.squares[cmd_r][cmd_c] or self.GetListOfValidMoves((cmd_r, cmd_c)) == []):
            print
            "Player", self.whoseturn
            cmd_r = int(input("  From row: "))
            cmd_c = int(input("  From col: "))
            if self.whoseturn == "black":
                ch = "b"
            else:
                ch = "w"

            if (self.squares[cmd_r][cmd_c] == 'e'):
                print
                "  Nothing there!"
            elif (ch not in self.squares[cmd_r][cmd_c]):
                print
                "  That's not your piece!"
            elif self.GetListOfValidMoves((cmd_r, cmd_c)) == []:
                print
                "  No valid moves for that piece!"

        return (cmd_r, cmd_c)

    def IsClearPath(self, fromTuple, toTuple):
        # Return true if there is nothing in a straight line between fromTuple and toTuple, non-inclusive
        # Direction could be +/- vertical, +/- horizontal, +/- diagonal
        fromSquare_r = fromTuple[0]
        fromSquare_c = fromTuple[1]
        toSquare_r = toTuple[0]
        toSquare_c = toTuple[1]
        fromPiece = self.squares[fromSquare_r][fromSquare_c]

        if abs(fromSquare_r - toSquare_r) <= 1 and abs(fromSquare_c - toSquare_c) <= 1:
            # The base case: just one square apart
            return True
        else:
            if toSquare_r > fromSquare_r and toSquare_c == fromSquare_c:
                # vertical +
                newTuple = (fromSquare_r + 1, fromSquare_c)

            elif toSquare_r < fromSquare_r and toSquare_c == fromSquare_c:
                # vertical -
                newTuple = (fromSquare_r - 1, fromSquare_c)

            elif toSquare_r == fromSquare_r and toSquare_c > fromSquare_c:
                # horizontal +
                newTuple = (fromSquare_r, fromSquare_c + 1)

            elif toSquare_r == fromSquare_r and toSquare_c < fromSquare_c:
                # horizontal -
                newTuple = (fromSquare_r, fromSquare_c - 1)

            elif toSquare_r > fromSquare_r and toSquare_c > fromSquare_c:
                # diagonal "SE"
                newTuple = (fromSquare_r + 1, fromSquare_c + 1)

            elif toSquare_r > fromSquare_r and toSquare_c < fromSquare_c:
                # diagonal "SW"
                newTuple = (fromSquare_r + 1, fromSquare_c - 1)

            elif toSquare_r < fromSquare_r and toSquare_c > fromSquare_c:
                # diagonal "NE"
                newTuple = (fromSquare_r - 1, fromSquare_c + 1)

            elif toSquare_r < fromSquare_r and toSquare_c < fromSquare_c:
                # diagonal "NW"
                newTuple = (fromSquare_r - 1, fromSquare_c - 1)

            if self.squares[newTuple[0]][newTuple[1]] != 'e':
                return False
            else:
                return self.IsClearPath(newTuple, toTuple)

    def GetListOfValidMoves(self, fromTuple):
        legalDestinationSpaces = []
        for row in range(8):
            for col in range(8):
                d = (row, col)
                if self.IsLegalMove(fromTuple, d):
                    if not self.DoesMovePutPlayerInCheck(fromTuple, d):
                        legalDestinationSpaces.append(d)
        return legalDestinationSpaces

    def IsLegalMove(self, fromTuple, toTuple):
        fromSquare_r = fromTuple[0]
        fromSquare_c = fromTuple[1]
        toSquare_r = toTuple[0]
        toSquare_c = toTuple[1]
        fromPiece = self.squares[fromSquare_r][fromSquare_c]
        toPiece = self.squares[toSquare_r][toSquare_c]

        if self.whoseturn == "black":
            enemyColor = 'w'
        if self.whoseturn == "white":
            enemyColor = 'b'

        if fromTuple == toTuple:
            return False

        if "P" in fromPiece:
            # Pawn
            if self.whoseturn == "black":
                if toSquare_r == fromSquare_r + 1 and toSquare_c == fromSquare_c and toPiece == 'e':
                    # moving forward one space
                    return True
                if fromSquare_r == 1 and toSquare_r == fromSquare_r + 2 and toSquare_c == fromSquare_c and toPiece == 'e':
                    # black pawn on starting row can move forward 2 spaces if there is no one directly ahead
                    if self.IsClearPath(fromTuple, toTuple):
                        return True
                if toSquare_r == fromSquare_r + 1 and (
                        toSquare_c == fromSquare_c + 1 or toSquare_c == fromSquare_c - 1) and enemyColor in toPiece:
                    # attacking
                    return True

            elif self.whoseturn == "white":
                if toSquare_r == fromSquare_r - 1 and toSquare_c == fromSquare_c and toPiece == 'e':
                    # moving forward one space
                    return True
                if fromSquare_r == 6 and toSquare_r == fromSquare_r - 2 and toSquare_c == fromSquare_c and toPiece == 'e':
                    # black pawn on starting row can move forward 2 spaces if there is no one directly ahead
                    if self.IsClearPath(fromTuple, toTuple):
                        return True
                if toSquare_r == fromSquare_r - 1 and (
                        toSquare_c == fromSquare_c + 1 or toSquare_c == fromSquare_c - 1) and enemyColor in toPiece:
                    # attacking
                    return True

        elif "R" in fromPiece:
            # Rook
            if (toSquare_r == fromSquare_r or toSquare_c == fromSquare_c) and (toPiece == 'e' or enemyColor in toPiece):
                if self.IsClearPath(fromTuple, toTuple):
                    return True

        elif "T" in fromPiece:
            # Knight
            col_diff = toSquare_c - fromSquare_c
            row_diff = toSquare_r - fromSquare_r
            if toPiece == 'e' or enemyColor in toPiece:
                if col_diff == 1 and row_diff == -2:
                    return True
                if col_diff == 2 and row_diff == -1:
                    return True
                if col_diff == 2 and row_diff == 1:
                    return True
                if col_diff == 1 and row_diff == 2:
                    return True
                if col_diff == -1 and row_diff == 2:
                    return True
                if col_diff == -2 and row_diff == 1:
                    return True
                if col_diff == -2 and row_diff == -1:
                    return True
                if col_diff == -1 and row_diff == -2:
                    return True

        elif "B" in fromPiece:
            # Bishop
            if (abs(toSquare_r - fromSquare_r) == abs(toSquare_c - fromSquare_c)) and (
                    toPiece == 'e' or enemyColor in toPiece):
                if self.IsClearPath(fromTuple, toTuple):
                    return True

        elif "Q" in fromPiece:
            # Queen
            if (toSquare_r == fromSquare_r or toSquare_c == fromSquare_c) and (toPiece == 'e' or enemyColor in toPiece):
                if self.IsClearPath(fromTuple, toTuple):
                    return True
            if (abs(toSquare_r - fromSquare_r) == abs(toSquare_c - fromSquare_c)) and (
                    toPiece == 'e' or enemyColor in toPiece):
                if self.IsClearPath(fromTuple, toTuple):
                    return True

        elif "K" in fromPiece:
            # King
            col_diff = toSquare_c - fromSquare_c
            row_diff = toSquare_r - fromSquare_r
            if toPiece == 'e' or enemyColor in toPiece:
                if abs(col_diff) == 1 and abs(row_diff) == 0:
                    return True
                if abs(col_diff) == 0 and abs(row_diff) == 1:
                    return True
                if abs(col_diff) == 1 and abs(row_diff) == 1:
                    return True

        return False  # if none of the other "True"s are hit above

    def GetPlayerInput_SquareTo(self, fromTuple):
        toTuple = ('x', 'x')

        validMoveList = self.GetListOfValidMoves(fromTuple)

        print
        "List of valid moves for piece at", fromTuple, ": ", validMoveList

        while (not toTuple in validMoveList):
            cmd_r = int(input("  To row: "))
            cmd_c = int(input("  To col: "))
            toTuple = (cmd_r, cmd_c)
            if not toTuple in validMoveList:
                print
                "  Invalid move!"

        return toTuple

    def GetPlayerInput(self):
        toTuple = (999, 999)
        while toTuple == (999, 999):
            fromTuple = self.GetPlayerInput_SquareFrom()
            toTuple = self.GetPlayerInput_SquareTo(fromTuple)

        return (fromTuple, toTuple)

    def MakeMove(self, moveTuple):
        fromSquare_r = moveTuple[0][0]
        fromSquare_c = moveTuple[0][1]
        toSquare_r = moveTuple[1][0]
        toSquare_c = moveTuple[1][1]

        fromPiece = self.squares[fromSquare_r][fromSquare_c]
        toPiece = self.squares[toSquare_r][toSquare_c]

        print
        fromPiece, "moves from square (" + str(fromSquare_r) + "," + str(fromSquare_c) + ") to square (" + str(
            toSquare_r) + "," + str(toSquare_c) + ")"
        if toPiece != 'e':
            print
            fromPiece, "captures", toPiece + "!"

        self.squares[toSquare_r][toSquare_c] = fromPiece
        self.squares[fromSquare_r][fromSquare_c] = 'e'

    def SetUpBoard(self, opt):
        if opt == 0:
            self.squares[0] = ['bR', 'bT', 'bB', 'bQ', 'bK', 'bB', 'bT', 'bR']
            self.squares[1] = ['bP', 'bP', 'bP', 'bP', 'bP', 'bP', 'bP', 'bP']
            self.squares[2] = ['e', 'e', 'e', 'e', 'e', 'e', 'e', 'e']
            self.squares[3] = ['e', 'e', 'e', 'e', 'e', 'e', 'e', 'e']
            self.squares[4] = ['e', 'e', 'e', 'e', 'e', 'e', 'e', 'e']
            self.squares[5] = ['e', 'e', 'e', 'e', 'e', 'e', 'e', 'e']
            self.squares[6] = ['wP', 'wP', 'wP', 'wP', 'wP', 'wP', 'wP', 'wP']
            self.squares[7] = ['wR', 'wT', 'wB', 'wQ', 'wK', 'wB', 'wT', 'wR']

        # Debugging set-ups
        # Testing IsLegalMove
        if opt == 1:
            self.squares[0] = ['bR', 'bT', 'bB', 'bQ', 'bK', 'bB', 'bT', 'bR']
            self.squares[1] = ['e', 'e', 'e', 'e', 'e', 'e', 'e', 'e']
            self.squares[2] = ['e', 'e', 'e', 'e', 'e', 'e', 'e', 'e']
            self.squares[3] = ['e', 'e', 'e', 'e', 'e', 'e', 'e', 'e']
            self.squares[4] = ['e', 'e', 'e', 'e', 'e', 'e', 'e', 'e']
            self.squares[5] = ['e', 'e', 'e', 'e', 'e', 'e', 'e', 'e']
            self.squares[6] = ['wP', 'wP', 'wP', 'wP', 'wP', 'wP', 'wP', 'wP']
            self.squares[7] = ['wR', 'wT', 'wB', 'wQ', 'wK', 'wB', 'wT', 'wR']

        # Testing IsInCheck, Checkmate
        if opt == 2:
            self.squares[0] = ['e', 'e', 'e', 'e', 'e', 'e', 'e', 'e']
            self.squares[1] = ['e', 'e', 'e', 'e', 'e', 'e', 'e', 'e']
            self.squares[2] = ['e', 'e', 'e', 'e', 'bK', 'e', 'e', 'e']
            self.squares[3] = ['e', 'e', 'e', 'e', 'bR', 'e', 'e', 'e']
            self.squares[4] = ['e', 'e', 'bB', 'e', 'e', 'e', 'e', 'e']
            self.squares[5] = ['e', 'e', 'e', 'e', 'e', 'e', 'e', 'e']
            self.squares[6] = ['wB', 'e', 'e', 'e', 'e', 'e', 'e', 'e']
            self.squares[7] = ['e', 'e', 'e', 'wK', 'wQ', 'e', 'e', 'e']

    def Draw(self):
        print
        "    c0   c1   c2   c3   c4   c5   c6   c7 "
        print
        "  ----------------------------------------"
        for r in range(8):
            print
            "r" + str(r) + "|",
            for c in range(8):
                if self.squares[r][c] != 'e':
                    print
                    str(self.squares[r][c]), "|",
                else:
                    print
                    "   |",
                if c == 7:
                    print  # to get a new line
            print
            "  ----------------------------------------"

    def MainLoop(self):
        print
        "Starting Chess..."
        self.whoseturn = "black"

        self.SetUpBoard(0)  # make sure arg is 0 for standard set-up

        while not self.IsCheckmate():
            self.Draw()

            if self.IsInCheck():
                print
                "Warning...", self.whoseturn, " player is in check!"

            move = self.GetPlayerInput()

            self.MakeMove(move)

            self.SwitchWhoseTurn()

        self.Draw()  # draw board a final time to show the end game setup
        print
        "Player ", self.whoseturn, " has lost the match!"

    def __init__(self):
        self.squares = [['e', 'e', 'e', 'e', 'e', 'e', 'e', 'e'], ['e', 'e', 'e', 'e', 'e', 'e', 'e', 'e'],
                        ['e', 'e', 'e', 'e', 'e', 'e', 'e', 'e'], ['e', 'e', 'e', 'e', 'e', 'e', 'e', 'e'],
                        ['e', 'e', 'e', 'e', 'e', 'e', 'e', 'e'], ['e', 'e', 'e', 'e', 'e', 'e', 'e', 'e'],
                        ['e', 'e', 'e', 'e', 'e', 'e', 'e', 'e'], ['e', 'e', 'e', 'e', 'e', 'e', 'e', 'e']]


if __name__ == "__main__":
    b = ChessBoard()
    b.MainLoop()