from sklearn.datasets import load_iris

# Load scikit's random forest classifier library
from sklearn.ensemble import RandomForestClassifier

# Load pandas
import pandas as pd

# Load numpy
import numpy as np

# Set random seed
np.random.seed(0)
iris = load_iris()
print("Iris",iris)
# Create a dataframe with the four feature variables
df = pd.DataFrame(iris.data, columns=iris.feature_names)
print("df",df)
# View the top 5 rows
print("Heads",df.head())
df['species'] = pd.Categorical.from_codes(iris.target, iris.target_names)

# View the top 5 rows
print("df1 ",df.head())
#Creating Training Dataset
df['is_train'] = np.random.uniform(0, 1, len(df)) <= .75

# View the top 5 rows
print("df2",df.head())
train, test = df[df['is_train']==True], df[df['is_train']==False]
print('Number of observations in the training data:', len(train))
print('Number of observations in the test data:',len(test))

#Process Data with features
features = df.columns[:4]

# View features
print("Features",features)
y = pd.factorize(train['species'])[0]

# View target
print("Y",y)
#Train the rendom forest classifier
clf = RandomForestClassifier(n_jobs=2, random_state=0)

# Train the Classifier to take the training features and learn how they relate
# to the training y (the species)
'''RandomForestClassifier(bootstrap=True, class_weight=None, criterion='gini',
            max_depth=None, max_features='auto', max_leaf_nodes=None,
            min_impurity_split=1e-07, min_samples_leaf=1,
            min_samples_split=2, min_weight_fraction_leaf=0.0,
            n_estimators=10, n_jobs=2, oob_score=False, random_state=0,
            verbose=0, warm_start=False)
'''
print(clf.fit(train[features], y))
# Apply the Classifier we trained to the test data (which, remember, it has never seen before)
print(clf.predict(test[features]))
# View the predicted probabilities of the first 10 observations
print(clf.predict_proba(test[features])[0:10])
preds = iris.target_names[clf.predict(test[features])]

# View the PREDICTED species for the first five observations
print(preds[0:5])
print(test['species'].head())
# Create confusion matrix
print(pd.crosstab(test['species'], preds, rownames=['Actual Species'], colnames=['Predicted Species']))
print(list(zip(train[features], clf.feature_importances_)))