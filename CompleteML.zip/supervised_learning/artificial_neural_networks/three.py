from matplotlib import pyplot as plt

cls = [[], []]
for point in points:
    cls[above_line(point, lin1)].append(tuple(point))
colours = ("r", "b")
for i in range(2):
    X, Y = zip(*cls[i])
    plt.scatter(X, Y, c=colours[i])

X = np.arange(-3, 120)

m = -p.weights[0] / p.weights[1]
print(m)
plt.plot(X, m * X, label="ANN line")
plt.plot(X, lin1(X), label="line1")
plt.legend()
plt.show()
