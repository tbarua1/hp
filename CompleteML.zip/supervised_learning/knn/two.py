import re

code_match = re.compile('<pre>(.*?)</pre>',
                        re.MULTILINE | re.DOTALL)
link_match = re.compile('<a href="http://.*?".*?>(.*?)</a>',
                        re.MULTILINE | re.DOTALL)


def extract_features_from_body(s):


    link_count_in_code = 0
# count links in code to later subtract them
    for match_str in code_match.findall(s):
        link_count_in_code +=len(link_match.findall(match_str))
    return len(link_match.findall(s))# – link_count_in_code
