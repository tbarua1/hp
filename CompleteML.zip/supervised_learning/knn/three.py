from sklearn.neighbors import KNeighborsClassifier
clf = KNeighborsClassifier(n_neighbors=5, p=2, metric='minkowski')
clf.fit(X_train, y_train)
# generate evaluation metrics
print("Train - Accuracy :", metrics.accuracy_score(y_train, clf.predict
(X_train)))
print("Train - Confusion matrix :",metrics.confusion_matrix(y_train, clf.
predict(X_train)))
print("Train - classification report :", metrics.classification_report
(y_train, clf.predict(X_train)))
print("Test - Accuracy :", metrics.accuracy_score(y_test, clf.predict
(X_test)))
print("Test - Confusion matrix :",metrics.confusion_matrix(y_test, clf.
predict(X_test)))
print("Test - classification report :", metrics.classification_report
(y_test, clf.predict(X_test)))