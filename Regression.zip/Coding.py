import matplotlib, seaborn, pandas

df = seaborn.load_dataset("tips")
print(df.head())
df.replace({ 'sex': {'Male':0 , 'Female':1} , 'smoker' : {'No': 0 , 'Yes': 1}} ,inplace=True)
print(df.head())

'''print(df.head())
print(df.info())
print(df.describe())
print(df.sample(3))
'''
# print(df.groupby("day").count())
'''df2 = df.groupby('day').sum()  # sum per day
df2.drop('size', inplace=True, axis=1)  # sum of size column is not relevant
df2['percent'] = df2['tip']/df2['total_bill']*100 # add percents
print(df2)'''

'''df3=df.groupby('smoker').sum()
df3['percent'] = df3['tip']/df3['total_bill']*100
print(df3)'''

'''df4= df.groupby(['day','size']).sum()
df4['percent'] = df4['tip']/df4['total_bill']*100
df4.dropna() # drop null rows
print(df4)'''

'''born.countplot(x='day', data=df)
seaborn.countplot(x='day',hue='size' ,data=df)'''
