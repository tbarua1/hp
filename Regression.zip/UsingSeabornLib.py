import matplotlib.pyplot as py
import seaborn as sb
import pandas as pd
df=sb.load_dataset('tips')
print(df.head())
print("Sample",df.sample(5))
print(df.info())
print(df.groupby('day').count())

df=df.groupby('day').sum() # sum per day
df.drop('size',inplace=True,axis=1) # sum of size column is not relevant
df['percent'] = df['tip']/df['total_bill']*100 # add percents