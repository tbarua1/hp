# y = b0 + b1 * x
# where b0 and b1 are cofficient of x an  y
#
# coefficient
# B1 = sum((x(i) - mean(x)) * (y(i) - mean(y))) / sum( (x(i) - mean(x))^2 )
# B0 = mean(y) - B1 * mean(x)
#
# calculate mean and variance
# mean(x) = sum(x) / count(x)
#
# variance = sum( (x - mean(x))^2 )
#
# covariance = sum((x(i) - mean(x)) * (y(i) - mean(y)))
#
# B1 = covariance(x, y) / variance(x)
#
# B0 = mean(y) - B1 * mean(x)