from pylab import *
import matplotlib.pyplot as plt
dt = 0.001
t = arange(0.0, 10.0, dt)
r = exp(-t[:1000]/0.05)
x = randn(len(t))
s = convolve(x,r)[:len(x)]*dt
plt.plot(t, s)
plot.axis([0, 1, 1.1*amin(s), 2*amax(s) ])
plt.xlabel('time (s)')
plt.ylabel('current (nA)')
plt.title('Gaussian colored noise')
a = axes([.65, .6, .2, .2], axisbg='y')
n, bins, patches = hist(s, 400, normed=1)
plt.title('Probability')
setp(a, xticks=[], yticks=[])
a = axes([0.2, 0.6, .2, .2], axisbg='y')
plt.plot(t[:len(r)], r)
plt.title('Impulse response')
setp(a, xlim=(0,.2), xticks=[], yticks=[])
plt.show()