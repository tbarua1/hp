from matplotlib import pyplot as plt

#Plotting to our canvas
plt.plot([1,4,7],[4,5,1])

#Showing what we plotted
plt.show()