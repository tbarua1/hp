import numpy as np
import matplotlib.pyplot as plt
__all__=['findOutliers']
def _isOutlier(x:list,midlleindex:int,halfwidth=5,threshold=4):
    window=np.hstack([x[midlleindex-halfwidth:midlleindex],x[midlleindex+1:midlleindex+halfwidth+1]])
    windowmean=np.mean(window)
    windowstd=np.std(window)
    if abs(x[midlleindex]-windowmean)>threshold*windowstd:
        return True
    return False
def findOutliers(x:list):
    outliers = [_isOutlier(x, i) for i in range(5, 100-5)]
    outlierIndice = [i + 5 for i in np.nonzero(outliers)]
    outlierValues = [x[i] for i in outlierIndice]
    return outlierIndice, outlierValues
if __name__ == '__main__':
    x = np.random.rand(1, 100).reshape(-1)
    x[40] += 2                                          
    x[27] += 3
    x[51]-=2
    (outlierInd                                         ice, outlierValues) = findOutliers(x)
    print(outlierIndice)
    plt.plot(x)
    plt.plot(outlierIndice, outlierValues, 'ro')
    plt.grid()
    plt.axis('tight')
    plt.show()