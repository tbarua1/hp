import numpy as np
import matplotlib.pyplot as plt
x=np.r_[-5:6]
y=[12.5,7,5,1.6,-1.1,-3.2,-2.6,-0.7,3.4,7.6,13]
Y=np.matrix(y)
M=np.vstack([np.power(np.matrix(x),2),np.ones(Y.shape)])
theta=Y*M.transpose()*np.linalg.inv(M*M.transpose())
print(theta)
xest=np.linspace(-5,5,41)
Mest=np.vstack([np.power(np.matrix(xest),2), np.ones((1,len(xest)))])
Yest=theta*Mest
yest=Yest.tolist()[0]
plt.plot(x,y,'b')
plt.plot(x,y,'bo')
plt.plot(xest,yest,'r:')
plt.grid()
plt.show()