import numpy as np
import matplotlib.pyplot as plt
x = np.linspace(0, 10)
line, = plt.plot(x, np.sin(x), '--', linewidth=2)
# 10 points on, 5 off, 100 on, 5 off
dashes = [10, 5, 100, 5]
line.set_dashes(dashes)
plt.show()