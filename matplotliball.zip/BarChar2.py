import numpy as np
import matplotlib.pyplot as plt
x = np.arange(5)
# assume there are 5 students
y = (20, 35, 30, 35, 27)
# plt.scatter(x,y)
plt.bar(x,y)
# scatter plot
plt.show()