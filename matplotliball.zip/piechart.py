import numpy as np
import matplotlib.pyplot as plt

n = 20
Z = np.random.uniform(0,1,n)
plt.title("Sample Pie Chart")
plt.pie(Z)
plt.show()