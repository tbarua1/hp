import numpy as np

from PIL import Image


def createExample():
    numberArrayExample =open('learning.txt','a')
    numbersWeHave=range(0,10)
    print(numbersWeHave)
    versionWeHave=range(1,10)
    print(versionWeHave)
    for eachNum in numbersWeHave:
        #numberArrayExample.write("\n")
        for eachVer in versionWeHave:
            #numberArrayExample.write(str(eachNum)+","+str(eachVer)+"\t")
            imgFilePath='images/numbers/'+str(eachNum)+'.'+str(eachVer)+'.png'
            print(imgFilePath)
            ei=Image.open(imgFilePath)
            eiar=np.array(ei)
            eiar1=str(eiar.tolist())
            lineToWrite=str(eachNum)+'::'+eiar1+'\n'
            numberArrayExample.write(lineToWrite)

createExample()