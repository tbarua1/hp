from PIL import Image
import numpy as np
i=Image.open("0.9.png")
iar=np.array(i)

print(iar)