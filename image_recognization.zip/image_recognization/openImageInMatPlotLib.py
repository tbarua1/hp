from PIL import Image
import numpy as np
import matplotlib.pyplot as plt

i=Image.open("images/sentdex.png")
iar=np.array(i)
fig=plt.figure()
ax1=plt.subplot2grid((8,6),(0,0),rowspan=4,colspan=4)
ax1=plt.subplot2grid((8,6),(0,0),rowspan=4,colspan=4)
ax1=plt.subplot2grid((8,6),(0,0),rowspan=4,colspan=4)
ax1=plt.subplot2grid((8,6),(0,0),rowspan=4,colspan=4)
ax1.imshow(iar)
ax1.imshow(iar)
ax1.imshow(iar)
ax1.imshow(iar)
plt.show()