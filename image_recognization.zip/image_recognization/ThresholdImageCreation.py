from functools import reduce

from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
def thresholdImage(imageArray):
    balanceArr=[]
    newArr=imageArray
    for eachRow in imageArray:
        for eachpix in eachRow:
            avgNum=reduce(lambda x,y:x+y,eachpix[:3])/len(eachpix[:3])
            balanceArr.append(avgNum)
            # print(eachpix)
            # time.sleep(5)
    balance=reduce(lambda x,y:x+y,balanceArr)/len(balanceArr)
    for eachRow in newArr:
        for eachpix in eachRow:
            if reduce(lambda x,y:x+y,eachpix[:3])/len(eachpix[:3])>balance:
                eachpix[0]=255 #Annotation Red Color
                eachpix[1]=255 #Annotation Green Color
                eachpix[2]=255 #Annotation Blue Color
                eachpix[3]=255 #Annotation HSB Color
            else:
                eachpix[0] = 0  # Annotation Red Color
                eachpix[1] = 0  # Annotation Green Color
                eachpix[2] = 0  # Annotation Blue Color
                eachpix[3] = 255  # Annotation HSB Color
    return newArr
i=Image.open("images/sentdex.png")
iar=np.array(i)
print(iar)
iar1=thresholdImage(iar)
fig=plt.figure()
ax1=plt.subplot2grid((8,6),(0,0),rowspan=4,colspan=4)
ax1.imshow(iar1)
plt.show()