from PIL import Image

scriptDir = "/home/tarkeshwar/"

PIL_Version = Image.VERSION

img_filename = "%s1.png" % scriptDir
im = Image.open(img_filename)
im.save("%s2.bmp" % scriptDir)