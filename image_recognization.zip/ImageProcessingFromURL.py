import io
from urllib.request import urlopen

from PIL import Image

response = urlopen("https://i.ytimg.com/vi/tJxcKyFMTGo/maxresdefault.jpg")
im_file = io.BytesIO(response.read())
im = Image.open(im_file)
im = im.rotate(90)
im = im.resize((800, 600))
im.save("downloaded_image.jpg", "JPEG")