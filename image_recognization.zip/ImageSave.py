from PIL import Image

size = 128, 128
filename = "1.png"
im = Image.open(filename)
im.thumbnail(size, Image.ANTIALIAS)
im.save(filename + ".thumbnail", "JPEG")