from PIL import Image

im = Image.open("1.png")
im.show()
data = list(im.getdata())
print(data)